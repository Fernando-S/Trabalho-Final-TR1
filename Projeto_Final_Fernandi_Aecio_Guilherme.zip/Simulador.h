#ifndef SIMULADOR_H
#define SIMULADOR_H

string binarioparastring(int *vetor, int size);

void AplicacaoReceptora (string mensagem);

void CamadaDeAplicacaoReceptora (int quadro [], int size);

#endif // SIMULADOR_H
